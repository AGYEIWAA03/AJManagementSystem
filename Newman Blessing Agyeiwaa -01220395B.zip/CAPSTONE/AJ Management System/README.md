--module-path "C:\Users\BLUEWAVE COMP\Downloads\openjfx-21.0.10_windows-x64_bin-sdk\javafx-sdk-21.0.10\lib" --add-modules javafx.controls,javafx.fxml

JDK Version Used: Java 21
JavaFX Version: 21.0.6

INSTRUCTIONS:
1. Ensure you have Java JDK 21 installed.
2. Download JavaFX SDK 21 from gluonhq.com.
3. Extract the SDK to a folder (e.g., C:\javafx\).
4. Update the path above to point to the 'lib' folder inside your JavaFX SDK.